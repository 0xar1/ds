#include <stdio.h>
#include <stdlib.h>
 
 
// Define doubly linked list structures
 
typedef struct link singleLink;
 
typedef struct trashLink singleTrashLink;
 
struct link {
    int data;
    singleLink * prev;
    singleLink * next;
};
 
struct trashLink {
    int trashdata;
    singleTrashLink * prev;
    singleTrashLink * next;
};
 
typedef struct linkedList
{
    int count;
    singleLink * first;
    singleLink * last;
}
doublyLinkedList;
 
typedef struct trashList
{
    int count;
    singleTrashLink * first;
    singleTrashLink * last;
}
trashLinkedList;
 
void DISPLAY_TRASH(trashLinkedList * list, int trashdata) // Function to reverse traverse the list and print out all items in it.
{
   singleTrashLink * trashLink;
   printf("\n");
   for (trashLink = list->first; trashLink; trashLink = trashLink->next) {
       trashdata = trashLink->trashdata;
       printf ("Trash output: \t%d\n", trashdata);
   }
}
 
void initiateList(doublyLinkedList * list) // Initiates the list by setting the first and the last links to 0.
{
   list->first = list->last = 0;
   list->count = 0;
}
 
void initiateTrashList(trashLinkedList * list) // Initiates the list by setting the first and the last links to 0.
{
   list->first = list->last = 0;
   list->count = 0;
}
 
void SKIP_INORDER(doublyLinkedList * list, int link2Delete) // Function to skip over the node to be deleted in the doubly linked list, but not to free it.
{
   int data = 0;
   singleLink * link;
   singleLink * next;
   // 
   for(link = list->first; link; link = next) {
          data = link->data;
       if (link2Delete == data) {
               next = link->next;
               return;
       }
   }
}
 
void addToTrash(trashLinkedList * trashList, /*doublyLinkedList * list,*/ int link2Delete) // Function to add one entry to the trash doubly linked list and checks for .
{
   int trashdata = 0;
   singleTrashLink * trashlink;
   singleLink * link;
   for (trashlink = trashList->first; trashlink; trashlink = trashlink->next) {
          trashdata = trashlink->trashdata;
       if (link2Delete == trashdata) {
               return;
       }
   }
   trashlink = calloc(1, sizeof (singleTrashLink)); // Allocate memory for single link.
   trashlink->trashdata = link2Delete;
   if(!link) { // Check if memory was correctly allocated.
       printf("Memory allocation was unsuccessful.\n");
       exit(0);
   }
   if(trashList->last) {
       trashList->last->next = trashlink;
       trashlink->prev = trashList->last;
       trashList->last = trashlink;
   }
   else {
       trashList->first = trashlink;
       trashList->last = trashlink;
   }
   trashList->count++;
}
 
void FREE_INORDER(doublyLinkedList * list) // Function to free the entire doubly linked list.
{
   singleLink * link;
   singleLink * next;
   // Goes through the list and frees each individual link.
   for(link = list->first; link; link = next) {
       next = link->next;
       free(link);   
   }
}
 
void clearFromList(doublyLinkedList * list, int link2Delete)
{
    singleLink * prev;
    singleLink * next;
    singleLink * link;
 
    int data = 0;
 
    //printf("got this far\n");
    for(link = list->first; link; link = next) {
        data = link->data;
        if (link2Delete == data) {
                prev = link->prev;
                next = link->next;
                //printf("got this far\n");
 
            if (prev) {
                if (next) {
                    /* Both the previous and next links are valid, so just
                       bypass "link" without altering "list" at all. */
                    prev->next = next;
                    next->prev = prev;
                }
                else {
                    /* Only the previous link is valid, so "prev" is now the
                       last link in "list". */
                    prev->next = 0;
                    list->last = prev;
                }
            }
            else {
                if (next) {
                    /* Only the next link is valid, not the previous one, so
                       "next" is now the first link in "list". */
                    next->prev = 0;
                    list->first = next;
                }
                else {
                    /* Neither previous nor next links are valid, so the list
                       is now empty. */
                    list->first = 0;
                    list->last = 0;
                }
            }
            //free (link);
            list->count--;
             
        }
    }
}
 
void addToList(doublyLinkedList * list, int data) // Function to add one entry to the doubly linked list.
{
   singleLink * link;
 
   link = calloc(1, sizeof (singleLink)); // Allocate memory for single link.
   link->data = data;
   if(!link) { // Check if memory was correctly allocated.
       printf("Memory allocation was unsuccessful.\n");
       exit(0);
   }
   if(list->last) {
       list->last->next = link;
       link->prev = list->last;
       list->last = link;
   }
   else {
       list->first = link;
       list->last = link;
   }
   list->count++;
}
 
void DISPLAY_INORDER(doublyLinkedList * list, int data) // Function to forward traverse the list and print out all items in it.
{
   singleLink * link;
   printf("\n");
   for (link = list->first; link; link = link->next) {
       data = link->data;
       printf ("Left to right output: \t%d\n", data);
   }
}
 
void DISPLAY_POSTORDER(doublyLinkedList * list, int data) // Function to reverse traverse the list and print out all items in it.
{
   singleLink * link;
   printf("\n");
   for (link = list->last; link; link = link->prev) {
       data = link->data;
       printf ("Right to left output: \t%d\n", data);
   }
}
 
int main(int argc, char *argv[]) // Main function.
{
 
   int data = 0;
   int trashdata = 0;
   char *end;
   int i;
   doublyLinkedList list;
   trashLinkedList trashList;
     
   initiateList(& list);
   initiateTrashList(& trashList);
    
   /* Manages the input command line argument and catches errors */
   /**/                                                         /**/
   /**/  if(argc == 2) {                                        /**/
    /**/     printf("\nCommand line argument: \t%s\n", argv[1]); /**/
    /**/  }                                                      /**/
   /**/  else if(argc > 2) {                                    /**/
    /**/     printf("\nMore than one argument supplied.\n\n");   /**/
    /**/     exit(0);                                            /**/
    /**/  }                                                      /**/
   /**/  else {                                                 /**/
    /**/     printf("\nOne argument expected.\n\n");             /**/
    /**/     exit(0);                                            /**/
    /**/  }                                                         /**/
    /**/  data = strtol(argv[1], &end, 0);                       /**/
    /**/  if (*end == '\0') {                                    /**/
   /**/     printf("\n");                                       /**/
   /**/  }                                                      /**/
   /**/  else {                                                 /**/
   /**/     printf("\nInvalid integer format.\n\n");            /**/
   /**/     exit(0);                                            /**/
   /**/  }                                                      /**/
    /**/  for(i = 0; i <= data; i++) {                           /**/
    /**/     addToList(&list, i);                                /**/
    /**/     printf("Input data: \t\t%d\n", i);                  /**/
    /**/  }                                                      /**/
    /*____________________________________________________________*/
     
    DISPLAY_INORDER(&list, 0); // Calls function to print list forwards.
     
    DISPLAY_POSTORDER(&list, 0); // Calls function to print list backwards.
 
     
    int link2Delete;
    int trashMaxNumber = rand() % data + 3;
    printf("\n");
    for(i = 0; i < trashMaxNumber; i++) {
        // Pick a random node (payload) to delete.
        link2Delete = (rand() % data);
        printf("Number Trashed: %d\n", link2Delete);
        addToTrash(&trashList, /*&list,*/ link2Delete);
        clearFromList(&list, link2Delete);
    }
     
    DISPLAY_TRASH(&trashList, 0); // Calls function to print trash list forwards.
    DISPLAY_INORDER(&list, 0); 
     
    FREE_INORDER(&list);
}
